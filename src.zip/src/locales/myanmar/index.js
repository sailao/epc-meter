const messages = {
    "Hello World": "Min galar par",
    Magic: "Start the Magic",
    units: 'သုံးစွဲယူနစ်',
    type: 'အမျိုးအစား',
    last_rate:'ယခင်နှုန်းထား',
    rate:'ယခုနှုန်းထား',
    home_plan: 'အိမ်သုံး',
    business_plan: 'လုပ်ငန်းသုံး',
    tai:'လိၵ်ႈတႆး',
    burma: 'မြန်မာစာ',
    english: 'အင်္ဂလိပ်စာ',
    keyboard: 'ကီးဘုတ်',
    remark: 'မီတာထိမ်းသိမ်းခ ၅၀၀ ကျပ် မပါသေး',
    welcome: 'မင်္ဂလာပါ',
    message: 'လျှပ်စစ်ဓာတ်အားခနှုန်းထားများ နှိုင်းယှဥ်ပြဇယား'
  };
  
  export default messages;
  