const messages = {
    "Hello World": "Mai Son kha",
    Magic: "Start the Magic",
    type: 'ၸၼ်ႉ',
    units: 'သုင်းယူႇၼိတ်ႉ',
    last_rate:'ဢွၼ်တၢင်း',
    rate:'မိူဝ်ႈလဵဝ်',
    home_plan: 'သုင်းႁိူၼ်း',
    business_plan: 'သုင်းၼႃႈၵၢၼ်',
    tai:'လိၵ်ႈတႆး',
    burma: 'မြန်မာစာ',
    english: 'လိၵ်ႈဢိင်းၵဵတ်း',
    keyboard: 'လွၵ်းမိုဝ်း',
    remark: 'ၼႆႉပႆႇပႃး ၶွၼ်ႇမီႇတႃႇ 500',
    welcome: 'မႂ်ႇသုင်ၶႃႈ',
    message: 'ၼႆႉပဵၼ် လွၵ်း​ႁၢင်ႈ ၼိူင်း​​ၼႄ ၵႃႈၶၼ်ၾႆးၾႃ.မိူဝ်ႈလဵဝ်'
  };
  
  export default messages;
  