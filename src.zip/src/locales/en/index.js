const messages = {
    "Hello World": "Hello i10n Next Hook",
    Magic: "Start the Magic",
    type: 'Type',
    units: 'Spend Unit',
    last_rate:'Pass Rate',
    rate:'Current Rate',
    home_plan: 'Home Plan',
    business_plan: 'Business Plan',
    tai:'လိၵ်ႈတႆး',
    burma: 'မြန်မာစာ',
    english: 'English',
    remark: 'not included extra charges 500.',
    welcome: 'Welcome',
    message: 'Table show different between electronic changes rate.'
  };
  
  export default messages;
  